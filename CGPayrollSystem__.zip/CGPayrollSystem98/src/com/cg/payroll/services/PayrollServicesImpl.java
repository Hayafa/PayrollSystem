package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.daoservices.AssociateDAO;
import com.cg.payroll.services.daoservices.AssociateDAOImpl;

public class PayrollServicesImpl implements PayrollServices {

	private  AssociateDAO associateDAO=new AssociateDAOImpl();
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
		Associate associate=new Associate(yearlyInvestmentUnder8oC, firstName, lastName, department, designation, pancard, emailId,new Salary(basicSalary, epf, companyPf, accountNumber, accountNumber, accountNumber, accountNumber, accountNumber, accountNumber, accountNumber),new BankDetails(accountNumber, bankName, ifscCode));
		associate=associateDAO.save(associate);
		return associate.getAssociateId();
	}

	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException  {
		Associate associate=getAssociateDetails(associateId);

		double a=associate.getSalary().getBasicSalary()-(250000+associate.getYearlyInvestmentUnder8oC()+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());
		double b=a-500000;
		double c=b-1000000;
		double netSalary;


		if(associate.getSalary().getBasicSalary()<=250000)
		{

			netSalary=associate.getSalary().getBasicSalary();
			return (int)netSalary;
		}
		else if(associate.getSalary().getBasicSalary()<=500000 && associate.getSalary().getBasicSalary()>250000)
		{
			netSalary=associate.getSalary().getBasicSalary()-(a*0.1);
			return(int) netSalary;

		}

		else if(associate.getSalary().getBasicSalary()<=1000000 && associate.getSalary().getBasicSalary()>500000) {
			netSalary=associate.getSalary().getBasicSalary()-((a*0.1)+b*0.2);
			return(int) netSalary;
		}
		else {
			netSalary=associate.getSalary().getCompanyPf()-((a*0.1)+(b*0.2)+(c*0.3));
			return (int)netSalary;
		}
	}
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null)throw new AssociateDetailsNotFoundException("'Associate details not found for id "+associateId);
		return associate ;
	}

	@Override
	public List<Associate> getAllAssociatesDetails() {

		return associateDAO.findAll();
	}

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName) {
		return 0;
	}

}


